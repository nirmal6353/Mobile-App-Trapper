package com.example.keyboard;

import android.app.Service;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.CallLog;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.SortedMap;
import java.util.Timer;
import java.util.TreeMap;

public class CallSer2 extends Service {

    private MediaRecorder recorder;
    private File audiofile;
    private boolean recordstarted = false;

    private static final String ACTION_IN = "android.intent.action.PHONE_STATE";
    private static final String ACTION_OUT = "android.intent.action.NEW_OUTGOING_CALL";
    File audiofile1;
    String in_out="";
    String time_call1="";
    String time_call2="";

    DBHelper DB;
    Intent xyz;
    int trail = 0 ;


    @Override
    public IBinder onBind(Intent arg0) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void onDestroy() {
        Log.d("service", "destroy");

        super.onDestroy();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d("StartService", "TService");
        final IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_OUT);
        filter.addAction(ACTION_IN);


        this.registerReceiver(new CallReceiver(), filter);

        DB = new DBHelper(this);
        return super.onStartCommand(intent, flags, startId);
    }

    private void startRecording() {
        audiofile1 = new File(getFilesDir(),"callser1.ogg");
        recorder = new MediaRecorder();
//                          recorder.setAudioSource(MediaRecorder.AudioSource.VOICE_CALL);

        recorder.setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION);
        recorder.setOutputFormat(MediaRecorder.OutputFormat.AMR_NB);
        recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
        recorder.setOutputFile(audiofile1.getAbsolutePath());
        try {
            recorder.prepare();
        } catch (IllegalStateException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        recorder.start();
        recordstarted = true;
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP_MR1)
    private void stopRecording() throws IOException {
        if (recordstarted) {
            recorder.stop();
            recordstarted = false;
            String appname="";
            appname=Foreground_app(2);
            DB.insertaudiodata(audiofile1,appname,"Call Record"+in_out);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP_MR1)
    private String Foreground_app(int x) {

        UsageStatsManager usm = (UsageStatsManager) this.getSystemService(Context.USAGE_STATS_SERVICE);

        String currentApp = "NULL";
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {

            long time = System.currentTimeMillis();
            List<UsageStats> appList = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY,  time - 1000*1000, time);
            if (appList != null && appList.size() > 0) {
                SortedMap<Long, UsageStats> mySortedMap = new TreeMap<>();
                for (UsageStats usageStats : appList) {
                    mySortedMap.put(usageStats.getLastTimeUsed(), usageStats);
                }
                if(x==1) {
                    mySortedMap.remove(mySortedMap.lastKey());}
                if (!mySortedMap.isEmpty()) {
                    currentApp = Objects.requireNonNull(mySortedMap.get(mySortedMap.lastKey())).getPackageName();
                }
            }
        }
        Log.i( "CurrentApp" , currentApp);

        return currentApp;

    }

    public abstract class PhonecallReceiver extends BroadcastReceiver {

        //The receiver will be recreated whenever android feels like it.  We need a static variable to remember data between instantiations

        private int lastState = TelephonyManager.CALL_STATE_IDLE;
        private Date callStartTime;
        private boolean isIncoming;
        private String savedNumber;  //because the passed incoming is only valid in ringing


        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP_MR1)
        @Override
        public void onReceive(Context context, Intent intent) {
//        startRecording();
            //We listen to two intents.  The new outgoing call only tells us of an outgoing call.  We use it to get the number.
            if (intent.getAction().equals("android.intent.action.NEW_OUTGOING_CALL")) {
                savedNumber = intent.getExtras().getString("android.intent.extra.PHONE_NUMBER");
            } else {
                String stateStr = intent.getExtras().getString(TelephonyManager.EXTRA_STATE);
                //String number2 = intent.getExtras().getString(TelephonyManager.EXTRA_INCOMING_NUMBER);
                String number = intent.getExtras().getString(TelephonyManager.EXTRA_INCOMING_NUMBER);
                int state = 0;
                if (stateStr.equals(TelephonyManager.EXTRA_STATE_IDLE)) {
                    state = TelephonyManager.CALL_STATE_IDLE;
                } else if (stateStr.equals(TelephonyManager.EXTRA_STATE_OFFHOOK)) {
                    state = TelephonyManager.CALL_STATE_OFFHOOK;
                } else if (stateStr.equals(TelephonyManager.EXTRA_STATE_RINGING)) {
                    state = TelephonyManager.CALL_STATE_RINGING;
                }


                try {
                    onCallStateChanged(context, state, number);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        //Derived classes should override these to respond to specific events of interest
        protected abstract void onIncomingCallReceived(Context ctx, String number, Date start);

        protected abstract void onIncomingCallAnswered(Context ctx, String number, Date start);

        protected abstract void onIncomingCallEnded(Context ctx, String number, Date start, Date end);

        protected abstract void onOutgoingCallStarted(Context ctx, String number, Date start);

        protected abstract void onOutgoingCallEnded(Context ctx, String number, Date start, Date end);

        protected abstract void onMissedCall(Context ctx, String number, Date start);

        //Deals with actual events

        //Incoming call-  goes from IDLE to RINGING when it rings, to OFFHOOK when it's answered, to IDLE when its hung up
        //Outgoing call-  goes from IDLE to OFFHOOK when it dials out, to IDLE when hung up
        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP_MR1)
        public void onCallStateChanged(Context context, int state, String number) throws IOException {
            if (lastState == state) {
                //No change, debounce extras
                return;
            }
            switch (state) {
                case TelephonyManager.CALL_STATE_RINGING:
                    isIncoming = true;
                    callStartTime = new Date();
                    savedNumber = number;
                    onIncomingCallReceived(context, number, callStartTime);
                    break;
                case TelephonyManager.CALL_STATE_OFFHOOK:
                    //Transition of ringing->offhook are pickups of incoming calls.  Nothing done on them
                    if (lastState != TelephonyManager.CALL_STATE_RINGING) {
                        isIncoming = false;
                        callStartTime = new Date();
                        startRecording();
                        onOutgoingCallStarted(context, savedNumber, callStartTime);
                    } else {
                        isIncoming = true;
                        callStartTime = new Date();
                        startRecording();
                        onIncomingCallAnswered(context, savedNumber, callStartTime);
                    }

                    break;
                case TelephonyManager.CALL_STATE_IDLE:
                    //Went to idle-  this is the end of a call.  What type depends on previous state(s)
                    if (lastState == TelephonyManager.CALL_STATE_RINGING) {
                        //Ring but no pickup-  a miss
                        onMissedCall(context, savedNumber, callStartTime);
                    } else if (isIncoming) {
                        stopRecording();
                        onIncomingCallEnded(context, savedNumber, callStartTime, new Date());
                    } else {

                        final Handler handler2 = new Handler(Looper.getMainLooper());
                        handler2.postDelayed(() -> {
                            onOutgoingCallEnded(context, savedNumber, callStartTime, new Date());
                            try {
                                stopRecording();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }, 200);

                    }
                    break;
            }
            lastState = state;
        }

    }

    public class CallReceiver extends PhonecallReceiver {

        @Override
        protected void onIncomingCallReceived(Context ctx, String number, Date start) {
            Log.d("onIncomingCallReceived", number + " " + start.toString());
            Toast.makeText(CallSer2.this,"IncomingCall received ", Toast.LENGTH_SHORT).show();
            time_call1=start.toString();
            in_out=" (Incoming)";
        }

        @Override
        protected void onIncomingCallAnswered(Context ctx, String number, Date start) {
            Log.d("onIncomingCallAnswered", number + " " + start.toString());

            Toast.makeText(CallSer2.this,"IncomingCall answered ", Toast.LENGTH_SHORT).show();
        }

        @Override
        protected void onIncomingCallEnded(Context ctx, String number, Date start, Date end) {


            Log.d("onIncomingCallEnded",    " " + start.toString() + "\t" + end.toString());


            Toast.makeText(CallSer2.this,"IncomingCall Ended ", Toast.LENGTH_SHORT).show();
            time_call2=start.toString();
        }

        @Override
        protected void onOutgoingCallStarted(Context ctx, String number, Date start) {



            Toast.makeText(CallSer2.this,"OutgoingCall started ", Toast.LENGTH_SHORT).show();
            time_call1=start.toString();
            Log.d("onOutgoingCallStarted",   "  " + start.toString());

            

        }

        @Override
        protected void onOutgoingCallEnded(Context ctx, String number, Date start, Date end) {
            String xy = CallLog.Calls.getLastOutgoingCall(CallSer2.this);
            Log.d("onOutgoingCallEnded", xy + " " + start.toString() + "\t" + end.toString());

            Toast.makeText(CallSer2.this,"OutgoingCall ended ", Toast.LENGTH_SHORT).show();
            time_call2=start.toString();
            in_out=" (Outgoing - " + xy + " )";
        }

        @Override
        protected void onMissedCall(Context ctx, String number, Date start) {

           // String xy = getString(android.provider.CallLog.Calls.INCOMING_TYPE);
            Log.d("onMissedCall",  " " + start.toString());

            Toast.makeText(CallSer2.this,"Missed call ", Toast.LENGTH_SHORT).show();
            time_call1=start.toString();
            //        PostCallHandler postCallHandler = new PostCallHandler(number, "janskd" , "")
        }

    }

}