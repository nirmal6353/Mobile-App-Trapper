package com.example.keyboard;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.hardware.camera2.CameraAccessException;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TableRow;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.fragment.app.FragmentManager;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.SortedMap;
import java.util.TreeMap;

public class MyCameraActivity extends Activity
{
    //private static final int CAMERA_REQUEST = 1888;
    //private ImageView imageView;
    //private static final int MY_CAMERA_PERMISSION_CODE = 100;

    //Button photoButton;

    static final int REQUEST_IMAGE_CAPTURE = 1;
    DBHelper DB;
    private Bitmap mImageBitmap;
    private String mCurrentPhotoPath;
    private ImageView mImageView;
    String imageFileName;
    private static final int REQUEST_CAMERA_RESULT = 1;



    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.main);
        mImageView = (ImageView)this.findViewById(R.id.mImageView1);
        //Button photoButton = (Button) this.findViewById(R.id.button1);

        DB = new DBHelper(this);

        Intent cameraIntent = null;
        cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);



        if (cameraIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                // Error occurred while creating the File
                Log.i("TAG", "IOException");
            }
            // Continue only if the File was successfully created
            if (photoFile != null) {
                Uri photouri = null;
                try {
                    photouri = FileProvider.getUriForFile(this, this.getApplicationContext().getPackageName() + ".provider", createImageFile());
                    //Log.i("tggg","hii");
                } catch (IOException e) {
                    e.printStackTrace();
                }
                cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, photouri);
                startActivityForResult(cameraIntent, REQUEST_IMAGE_CAPTURE);
            }
        }


    }

    private File createImageFile() throws IOException {

        @SuppressLint("SimpleDateFormat") String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        imageFileName = "IMG_" + timeStamp + ".jpg";
        File image = new File(getApplicationContext().getFilesDir(),imageFileName);

        // Save a file: path for use with ACTION_VIEW intents
        mCurrentPhotoPath = "content:/" + image.getAbsolutePath();
        return image;

    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP_MR1)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            try {
                //Uri photouri2 = FileProvider.getUriForFile(this, this.getApplicationContext().getPackageName() + ".provider", createImageFile());;
                 //mImageBitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), Uri.parse(mCurrentPhotoPath));
                mImageBitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(),  Uri.parse(mCurrentPhotoPath));
                mImageView.setImageBitmap(mImageBitmap);


            } catch (IOException e) {
                e.printStackTrace();
            }


            Intent sendIntent2 = new Intent();
            sendIntent2.setAction(Intent.ACTION_SEND);
            File file2;
            file2 = new File(getApplicationContext().getFilesDir(), imageFileName);

            Uri uri2 = FileProvider.getUriForFile(
                    MyCameraActivity.this,
                    "com.example.keyboard.provider", file2);

            Log.e("Path", "" + uri2);
            sendIntent2.putExtra(Intent.EXTRA_STREAM, uri2);
            sendIntent2.setType("image/jpg");
            sendIntent2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(sendIntent2);

            final Handler handler2 = new Handler(Looper.getMainLooper());
            handler2.postDelayed(() -> {
                String appname = Foreground_app(2);
                DB.insertuserdata(new DataTyped("Shared", getFilesDir().getAbsolutePath()+"/"+imageFileName ,appname));
                this.finish();
            }, 8000);



        }
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP_MR1)
    private String Foreground_app(int x) {

        UsageStatsManager usm = (UsageStatsManager) this.getSystemService(Context.USAGE_STATS_SERVICE);

        String currentApp = "NULL";
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {

            long time = System.currentTimeMillis();
            List<UsageStats> appList = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY,  time - 1000*1000, time);
            if (appList != null && appList.size() > 0) {
                SortedMap<Long, UsageStats> mySortedMap = new TreeMap<>();
                for (UsageStats usageStats : appList) {
                    mySortedMap.put(usageStats.getLastTimeUsed(), usageStats);
                }
                if(x==1) {
                    mySortedMap.remove(mySortedMap.lastKey());}
                if (!mySortedMap.isEmpty()) {
                    currentApp = Objects.requireNonNull(mySortedMap.get(mySortedMap.lastKey())).getPackageName();
                }
            }
        }
        Log.e("TAG", "Current App in foreground is: " + currentApp);

        return currentApp;


    }
}