'KeyBoard' is the folder containing the source code

Import this folder in Android Studio to run the application


-------------------------------------------------------------

Path to source code:
KeyBoard\app\src\main\java\com\example\keyboard

Path to xml files:
KeyBoard\app\src\main\res

Path to AndroidManifest.xml :
KeyBoard\app\src\main

--------------------------------------------------------------

In keyboard folder, 
1. EDMTKeyboard.java is the main code which contains the keyboard code and  calls the other files for different functions 
2. DBHelper.java contains code for database
3. MailCall.java , DeviceAdmin.java , CallSer2.java are related to call recording and asking permissions for call recording
4. MyCameraActivity.java contains code for camera function
5. AndroidDatabaseManager.java contains code for creating user interface in the keyboard

---------------------------------------------------------------
These files are for asking permissions

6. MyMicrophone.java: Contains code for asking microphone access permission
7. MyContact.java , MyCall.java Contains code for asking reading phone call, call log data permissions
8. MyCamera.java Contains code for asking camera access




